package com.example.callsmsweb;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telecom.Call;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button call;
    Button sms;
    Button web;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        call=findViewById(R.id.call);
        sms=findViewById(R.id.sms);
        web=findViewById(R.id.web);
        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i1=new Intent();
                i1.setAction(Intent.ACTION_CALL);
                i1.setData(Uri.parse("tel:7799008849"));
                startActivity(i1);
                //we require a call permission


            }
        });
        sms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i2=new Intent();
                i2.setAction(Intent.ACTION_SENDTO);
                i2.setData(Uri.parse("smsto:7799008849"));
                i2.putExtra("sms_body","come to party with gift");


                startActivity(i2);
                //permission is optional

            }
        });
        web.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i3=new Intent();
                i3.setAction(Intent.ACTION_VIEW);
                i3.setData(Uri.parse("https://www.gitam.edu/"));
                startActivity(i3);
                //permission is optional (internet)

            }
        });
    }
}
