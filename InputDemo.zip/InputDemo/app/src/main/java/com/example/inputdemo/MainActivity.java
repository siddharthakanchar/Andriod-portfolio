package com.example.inputdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText ip;
    Button compute;
    TextView tv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ip=findViewById(R.id.ip);
        compute=findViewById(R.id.compute);
        tv=findViewById(R.id.tv);
        compute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                String name=ip.getText().toString();
//                tv.setText("you have given :"+name);
                int num=Integer.parseInt(ip.getText()toString());
                if (num%2==0)
                {
                tv.setText("even number");
            }
                else
                {
                    tv.setText("odd number");

                }
        });
    }
}
