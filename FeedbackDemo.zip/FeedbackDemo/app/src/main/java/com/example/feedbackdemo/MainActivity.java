package com.example.feedbackdemo;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.RatingBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    RatingBar fb;
    TextView result;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fb=findViewById(R.id.fb);
        result=findViewById(R.id.result);
        fb.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                int myvalue=(int)rating;
                switch (myvalue)
                {
                    case 1:
                        result.setText("you are poor");
                        result.setTextColor(Color.BLUE);
                        break;
                    case 2:
                        result.setText("you are good");
                        result.setTextColor(android.R.color.holo_red_light);
                        break;
                    case 3:
                        result.setText("you are very good");
                        result.setTextColor(android.R.color.holo_green_dark);
                        break;
                    case 4:
                        result.setText("you are great");
                        result.setTextColor(android.R.color.holo_orange_dark);
                        break;
                    case 5:
                        result.setText("you are excellent");
                        result.setTextColor(android.R.color.holo_purple);
                        break;




                }

            }
        });
    }
}
