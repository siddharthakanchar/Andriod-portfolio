package com.example.buttondemo;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
//gobal declaration
    int a;
    LinearLayout siddhartha;
    Button b1;
    //2 ids are declared in xml for two variables in java
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        siddhartha=findViewById(R.id.ml);
        b1=findViewById(R.id.cts);
        // above lines  are defining the variables
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                b1.setText("you have clicked");
                // changing the text of the button after the click
                siddhartha.setBackgroundColor(Color.YELLOW);
                Toast.makeText(MainActivity.this, "siddhartha kancharla", Toast.LENGTH_SHORT).show();
                int x=10;
                int y=20,z=x+y:
                b1.setText("addition is "+z);



            }
        });

    }
}
