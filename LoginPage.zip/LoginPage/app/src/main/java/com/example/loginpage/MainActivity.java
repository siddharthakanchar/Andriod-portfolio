package com.example.loginpage;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText un,pwd;
Button lgn,reg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        un=findViewById(R.id.un);
        pwd=findViewById(R.id.pwd);
        lgn=findViewById(R.id.lgn);
        reg=findViewById(R.id.reg);
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              Intent sid =new Intent(MainActivity.this,RegisterPage.class);
            }
        });
        lgn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (un.getText().toString().equals("kk") && pwd.getText().toString().equals("1234"))
                {
                    Intent sid= new Intent(MainActivity.this,Homepage.class);
                    startActivity(sid);

                    Toast.makeText(MainActivity.this, "Valid user", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "invalid user", Toast.LENGTH_SHORT).show();

                }}

        });
    }
}
